import React, { useEffect, useRef } from 'react';

type SceneObject = {
  id: string;
  className: string;
  delay: number;
  drift: number;
  content: React.ReactNode;
};

const objects: SceneObject[] = [
  { id: 'application', className: 'scene-application', delay: .16, drift: 14, content: <><span className="check">&#10003;</span><strong>Application<br />submitted!</strong></> },
  { id: 'resume', className: 'scene-resume', delay: .04, drift: 10, content: <><span className="resume-band" /><strong>Product Designer<br />Cruise</strong><p>We're building the world's most advanced self-driving vehicles.</p></> },
  { id: 'tips', className: 'scene-tips', delay: .68, drift: 34, content: <><b>8</b><span>chapters of juicy<br />tips &amp; tricks</span></> },
  { id: 'compass', className: 'scene-compass', delay: 1.18, drift: -54, content: <span>&#9670;</span> },
  { id: 'early', className: 'scene-early', delay: .92, drift: 22, content: <><strong>Great for early-<br />career designers</strong><p>Everything you need to land that first role.</p></> },
  { id: 'portfolio', className: 'scene-portfolio', delay: .1, drift: -12, content: <><div className="browser-bar"><b>Jane W.</b><span>Portfolio&nbsp;&nbsp;&nbsp; About</span></div><div className="portfolio-grid"><i /><i /><i /></div></> },
  { id: 'mapper', className: 'scene-mapper', delay: .58, drift: -30, content: <><div className="mini-window-dots">&#9679;&nbsp;&#9679;&nbsp;&#9679;</div><div className="map-lines" /><strong>Mapper</strong><small>iOS app for making maps</small></> },
  { id: 'case-study', className: 'scene-case-study', delay: 1.08, drift: 18, content: <>CRUSH<br />THE<br />CASE<br />STUDY</> },
];

type Body = {
  element: HTMLDivElement;
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  angle: number;
  angularVelocity: number;
  mass: number;
  delay: number;
  squash: number;
  active: boolean;
};

const readDegrees = (element: HTMLElement, property: string) => {
  const value = getComputedStyle(element).getPropertyValue(property);
  return Number.parseFloat(value) || 0;
};

const FallingScene: React.FC = () => {
  const sceneRef = useRef<HTMLDivElement>(null);
  const objectRefs = useRef<Array<HTMLDivElement | null>>([]);

  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    let frame = 0;
    let resizeTimer = 0;
    let stopped = false;

    const startSimulation = () => {
      cancelAnimationFrame(frame);
      scene.classList.remove('physics-active');
      objectRefs.current.forEach((element) => {
        if (!element) return;
        ['left', 'right', 'top', 'bottom', 'opacity', 'transform'].forEach((property) => element.style.removeProperty(property));
      });

      const sceneWidth = scene.clientWidth;
      const sceneHeight = scene.clientHeight;
      const elements = objectRefs.current.filter((element): element is HTMLDivElement => Boolean(element && element.offsetWidth));

      const bodies: Body[] = elements.map((element) => {
        const config = objects[Number(element.dataset.index)];
        const width = element.offsetWidth;
        const height = element.offsetHeight;
        const startAngle = readDegrees(element, '--start-rotate');
        const endAngle = readDegrees(element, '--end-rotate');
        return {
          element,
          x: element.offsetLeft,
          y: -height - 70 - Number(element.dataset.index) * 24,
          width,
          height,
          velocityX: config.drift,
          velocityY: 0,
          angle: startAngle,
          angularVelocity: (endAngle - startAngle) / 1.35,
          mass: Math.max(1, width * height / 18000),
          delay: config.delay,
          squash: 0,
          active: false,
        };
      });

      scene.classList.add('physics-active');
      bodies.forEach((body) => {
        body.element.style.left = '0';
        body.element.style.right = 'auto';
        body.element.style.top = '0';
        body.element.style.bottom = 'auto';
      });

      const startedAt = performance.now();
      let previousTime = startedAt;

      const collide = (upper: Body, lower: Body) => {
        const overlap = Math.min(upper.x + upper.width, lower.x + lower.width) - Math.max(upper.x, lower.x);
        const penetration = upper.y + upper.height - lower.y;
        if (overlap <= Math.min(upper.width, lower.width) * .16 || penetration < 0 || penetration > upper.height * .55) return;
        if (upper.y + upper.height * .5 >= lower.y + lower.height * .5) return;

        upper.y -= penetration;
        const relativeVelocity = upper.velocityY - lower.velocityY;
        if (relativeVelocity <= 0) return;

        const restitution = relativeVelocity > 240 ? .34 : 0;
        const impulse = (1 + restitution) * relativeVelocity / (1 / upper.mass + 1 / lower.mass);
        upper.velocityY -= impulse / upper.mass;
        lower.velocityY += impulse / lower.mass;

        const offset = (upper.x + upper.width / 2 - (lower.x + lower.width / 2)) / Math.max(40, lower.width / 2);
        upper.velocityX += offset * Math.min(relativeVelocity, 700) * .16;
        upper.angularVelocity += offset * Math.min(relativeVelocity, 700) * .045;
        if (overlap < upper.width * .5) upper.velocityX += Math.sign(offset || 1) * 65;
        upper.squash = Math.min(1, relativeVelocity / 620);
        lower.squash = Math.max(lower.squash, upper.squash * .55);
      };

      const tick = (time: number) => {
        if (stopped) return;
        const elapsed = (time - startedAt) / 1000;
        const delta = Math.min((time - previousTime) / 1000, .032);
        previousTime = time;

        bodies.forEach((body) => {
          if (!body.active && elapsed >= body.delay) body.active = true;
          if (!body.active) return;
          body.velocityY += 1550 * delta;
          body.x += body.velocityX * delta;
          body.y += body.velocityY * delta;
          body.angle += body.angularVelocity * delta;
          body.velocityX *= Math.pow(.995, delta * 60);
          body.angularVelocity *= Math.pow(.992, delta * 60);
          body.squash *= Math.pow(.82, delta * 60);

          const sideLimit = body.width * .2;
          if (body.x < -sideLimit) {
            body.x = -sideLimit;
            body.velocityX = Math.abs(body.velocityX) * .45;
          } else if (body.x + body.width > sceneWidth + sideLimit) {
            body.x = sceneWidth + sideLimit - body.width;
            body.velocityX = -Math.abs(body.velocityX) * .45;
          }
        });

        for (let pass = 0; pass < 3; pass += 1) {
          const activeBodies = bodies.filter((body) => body.active).sort((a, b) => a.y - b.y);
          for (let i = 0; i < activeBodies.length; i += 1) {
            for (let j = i + 1; j < activeBodies.length; j += 1) collide(activeBodies[i], activeBodies[j]);
          }

          activeBodies.forEach((body) => {
            if (body.y + body.height < sceneHeight) return;
            body.y = sceneHeight - body.height;
            if (body.velocityY > 65) {
              body.squash = Math.min(1, body.velocityY / 720);
              body.velocityY *= -.3;
            } else {
              body.velocityY = 0;
            }
            body.velocityX *= .82;
            body.angularVelocity *= .72;
          });
        }

        bodies.forEach((body) => {
          if (!body.active) return;
          const scaleX = 1 + body.squash * .07;
          const scaleY = 1 - body.squash * .1;
          body.element.style.opacity = '1';
          body.element.style.transform = `translate3d(${body.x.toFixed(2)}px, ${body.y.toFixed(2)}px, 0) rotate(${body.angle.toFixed(2)}deg) scale(${scaleX.toFixed(3)}, ${scaleY.toFixed(3)})`;
        });

        frame = requestAnimationFrame(tick);
      };

      frame = requestAnimationFrame(tick);
    };

    startSimulation();
    const handleResize = () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(startSimulation, 160);
    };
    window.addEventListener('resize', handleResize);
    return () => {
      stopped = true;
      cancelAnimationFrame(frame);
      window.clearTimeout(resizeTimer);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div ref={sceneRef} className="falling-scene" aria-hidden="true">
      {objects.map(({ id, className, content }, index) => (
        <div
          ref={(element) => { objectRefs.current[index] = element; }}
          className={`falling-object ${className}`}
          data-index={index}
          key={id}
        >
          <div className="falling-object-inner">{content}</div>
        </div>
      ))}
    </div>
  );
};

export default FallingScene;